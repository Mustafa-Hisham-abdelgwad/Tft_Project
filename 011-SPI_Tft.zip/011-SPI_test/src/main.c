


#include "LIB/STD_TYPES.h"
#include "MCAL/RCC/RCC_int.h"
#include "MCAL/GPIO/GPIO_int.h"
//#include "MCAL/SPI/SPI_int.h"
#include "HAL/TFT/TFT_int.h"

#include "tft_test_img.h"

int main(void)
{

	MRCC_vInit();
	MRCC_vEnableClock(RCC_AHB1, RCC_EN_GPIOA);
	MRCC_vEnableClock(RCC_APB2, RCC_EN_SPI1);

	TFT_vInit();

//	TFT_vShowImage(tft_test_img, sizeof(tft_test_img)/sizeof(tft_test_img[0]));

	Color_t bg;

	bg.pixel.Blu = 0b11111 ;
	bg.pixel.Grn = 0 ;
	bg.pixel.Red = 0 ;

	Color_t  rect_color = {
			.pixel.blu = 0,
			.pixel.Grn = 0b111111,
			.pixel.Red = 0
	};

	TFT_vFillBackground(bg);


	TFT_vSetXPos(20,20+30);
	TFT_vSetYPos(20,20+60);
	TFT_vFillRectangle(rect_color);

/**
 *   0 0 0 0 0 0 0 0
 *   0 0 0 0 0 0 0 0
 *   0 0 0 0 0 0 0 0
 *   0 0 0 0 1 1 0 0
 *   0 0 0 0 0 1 0 0
 *   0 0 0 0 0 1 0 0
 *   0 0 0 0 0 0 0 0
 *   0 0 0 0 0 0 0 0
 */




#if 0
	MGPIO_Config_t ledpin = {
GPIO_PORTA, GPIO_PIN0, GPIO_MODE_OUTPUT, GPIO_SPEED_LOW, GPIO_OTYPE_PUSHPULL
	};

	MGPIO_vInit(&ledpin);

	MSPI_vInit();

	u8 c=0;

	c = MSPI_u16Transceive('M');


	if(c == 'M')
	{
		MGPIO_vSetPinVal(ledpin.Port, ledpin.Pin, GPIO_HIGH);
	}
	else
	{
		MGPIO_vSetPinVal(ledpin.Port, ledpin.Pin, GPIO_LOW);
	}
#endif

	while(1)
	{

	}
}
