/*
 * TFT_prv.h
 *
 *  Created on: Sep 29, 2022
 *      Author: mazen
 */

#ifndef HAL_TFT_TFT_PRV_H_
#define HAL_TFT_TFT_PRV_H_





#endif /* HAL_TFT_TFT_PRV_H_ */
