/*
 * SPI_int.h
 *
 *  Created on: Sep 27, 2022
 *      Author: mazen
 */

#ifndef MCAL_SPI_SPI_INT_H_
#define MCAL_SPI_SPI_INT_H_

void MSPI_vInit(void);
u16  MSPI_u16Transceive(u16 A_u16Data);



#endif /* MCAL_SPI_SPI_INT_H_ */
