/*
 * SPI_cfg.h
 *
 *  Created on: Sep 27, 2022
 *      Author: mazen
 */

#ifndef MCAL_SPI_SPI_CFG_H_
#define MCAL_SPI_SPI_CFG_H_


#define SPI1_BAUDRATE    0b101


#endif /* MCAL_SPI_SPI_CFG_H_ */
